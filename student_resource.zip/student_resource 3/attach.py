import pandas as pd

# Read the CSV files
combined_df = pd.read_csv(r"C:\Users\adity\Downloads\test_out_combined.csv")
reference_df = pd.read_csv(r"student_resource 3\dataset\test.csv")

# Extract the indices (first column) from both DataFrames
combined_indices = combined_df.iloc[:, 0].tolist()
reference_indices = reference_df.iloc[:, 0].tolist()

# Create a new DataFrame with all indices from the reference DataFrame
all_indices = pd.DataFrame({combined_df.columns[0]: reference_indices})

# Merge the combined DataFrame with the reference indices (outer join to include all reference indices)
merged_df = pd.merge(all_indices, combined_df, on=combined_df.columns[0], how='left')

# Replace missing rows with an empty string ""
merged_df.fillna("", inplace=True)

# Save the result to a new CSV file
merged_df.to_csv(r"C:\Users\adity\Downloads\test_out_final.csv", index=False)

print("Comparison complete, missing values filled, and saved successfully!")
