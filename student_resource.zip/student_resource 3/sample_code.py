import os
import pandas as pd
import requests
from PIL import Image, ImageFilter
import numpy as np
import easyocr
import re
import shutil
import csv
from ultralytics import YOLO

# Initialize EasyOCR Reader
reader = easyocr.Reader(['en'])

# Shorthand to formal unit mapping
unit_conversion_map = {
    'cm': 'centimetre',
    'cn': 'centimetre',
    'm': 'metre',
    'mm': 'millimetre',
    'inch': 'inch',
    'ft': 'foot',
    'kg': 'kilogram',
    'g': 'gram',
    'mg': 'milligram',
    'oz': 'ounce',
    'lb': 'pound',
    'V': 'volt',
    'v': 'volt',
    'kV': 'kilovolt',
    'W': 'watt',
    'kW': 'kilowatt'
}

# Entity unit map from your provided dataset
entity_unit_map = {
    'width': {'centimetre', 'foot', 'inch', 'metre', 'millimetre', 'yard'},
    'depth': {'centimetre', 'foot', 'inch', 'metre', 'millimetre', 'yard'},
    'height': {'centimetre', 'foot', 'inch', 'metre', 'millimetre', 'yard'},
    'item_weight': {'gram', 'kilogram', 'microgram', 'milligram', 'ounce', 'pound', 'ton'},
    'maximum_weight_recommendation': {'gram', 'kilogram', 'microgram', 'milligram', 'ounce', 'pound', 'ton'},
    'voltage': {'kilovolt', 'millivolt', 'volt'},
    'wattage': {'kilowatt', 'watt'},
    'item_volume': {'centilitre', 'cubic foot', 'cubic inch', 'cup', 'decilitre', 'fluid ounce', 'gallon',
                    'imperial gallon', 'litre', 'microlitre', 'millilitre', 'pint', 'quart'}
}

# Function to download image and process it
def download_image(image_url, index):
    try:
        response = requests.get(image_url, stream=True)
        img = Image.open(response.raw)
        temp_image_path = f"temp_image_{index}.jpg"
        img.save(temp_image_path)
        return temp_image_path
    except Exception as e:
        print(f"Error downloading image for index {index}: {e}")
        return None

# Extract numeric value and unit from OCR result
def extract_value_and_unit(text):
    try:
        match = re.search(r'(\d+\.?\d*)\s*([a-zA-Z]+)', text)
        if match:
            value = match.group(1)
            unit = match.group(2).lower()
            # Normalize the unit using the unit_conversion_map
            normalized_unit = unit_conversion_map.get(unit, unit)
            return float(value), normalized_unit
    except Exception as e:
        print(f"Error extracting value and unit: {e}")
    return None, None

def float_to_int_if_possible(value):
    if value.is_integer():
        return int(value)
    return value

def predictor(index, image_link, entity_name):
    temp_image_path = download_image(image_link, index)
    if not temp_image_path:
        return ""

    try:
        # Load YOLO model
        model_path = "/kaggle/input/ml-hackathon/student_resource 3/runs/detect/train/weights/best.pt"
        model = YOLO(model_path)
        
        # Run YOLO on the image
        results = model(temp_image_path, conf=0.01, save=True, project="/content/drive/MyDrive/runs/detect")
        
        # Process YOLO results
        best_prediction = None
        highest_confidence = -1
        predictions = []  # To store predictions for alternative checks
        
        with Image.open(temp_image_path) as img:
            for result in results:
                boxes = result.boxes
                class_names = [result.names[int(box.cls.item())] for box in boxes]
                
                for box, class_name in zip(boxes, class_names):
                    try:
                        x1, y1, x2, y2 = box.xyxy[0].tolist()
                        confidence = box.conf.item()
                        
                        # Extract and preprocess the region of interest
                        roi_width = int(x2) - int(x1)
                        roi_height = int(y2) - int(y1)
                        
                        if roi_width > 0 and roi_height > 0:
                            roi = img.crop((int(x1), int(y1), int(x2), int(y2))).convert("L")
                            roi = roi.filter(ImageFilter.SHARPEN)
                            new_size = (roi.width * 2, roi.height * 2)
                            roi = roi.resize(new_size, Image.Resampling.LANCZOS)
                            
                            # Apply EasyOCR to the preprocessed ROI
                            ocr_result = reader.readtext(np.array(roi), detail=0)
                            
                            # Process OCR results
                            for text in ocr_result:
                                value, unit = extract_value_and_unit(text)
                                if value and unit:
                                    if class_name == entity_name:
                                        if unit in entity_unit_map.get(entity_name, {}):
                                            if confidence > highest_confidence:
                                                highest_confidence = confidence
                                                best_prediction = float_to_int_if_possible(value)
                                                best_unit = unit
                                    else:
                                        predictions.append((class_name, value, unit, confidence))
                        else:
                            print(f"Invalid ROI dimensions for index {index}: width={roi_width}, height={roi_height}")
                    
                    except Exception as e:
                        print(f"Error processing bounding box for index {index}: {e}")
        
        # Handle fallback for "weight" related entities
        if "weight" in entity_name and not best_prediction:
            for class_name, value, unit, confidence in predictions:
                if class_name == "item_weight":
                    if unit in entity_unit_map.get("maximum_weight_recommendation", {}):
                        if confidence > highest_confidence:
                            highest_confidence = confidence
                            best_prediction = float_to_int_if_possible(value)
                            best_unit = unit
        
        # Clean up temporary files
        shutil.rmtree("/kaggle/input/ml-hackathon/student_resource 3/runs/detect", ignore_errors=True)
        
        # Ensure the image file is deleted after processing
        if os.path.exists(temp_image_path):
            os.remove(temp_image_path)
        
        # Return the best prediction or an empty string
        if best_prediction and best_unit:
            return f"{best_prediction} {best_unit}"
    except Exception as e:
        print(f"Error processing image for index {index}: {e}")
    return ""

if __name__ == "__main__":
    DATASET_FOLDER = '/kaggle/input/ml-hackathon/student_resource 3/dataset'
    
    try:
        test = pd.read_csv(os.path.join(DATASET_FOLDER, 'test.csv'))
    except Exception as e:
        print(f"Error reading CSV file: {e}")
        exit(1)
    
    # Filter the rows between the specified indices (75,000 to 119,844 inclusive)
    test_filtered = test
    
    # Prepare the output CSV file
    output_filename = '/kaggle/working/test_out.csv'
    with open(output_filename, 'w', newline='') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow(['index', 'prediction'])  # Write header
        
        previous_image_path = None
        
        # Process each row
        for _, row in test_filtered.iterrows():
            try:
                # Delete the previous image if it exists
                if previous_image_path and os.path.exists(previous_image_path):
                    os.remove(previous_image_path)
                
                prediction = predictor(row['index'], row['image_link'], row['entity_name'])
                csvwriter.writerow([row['index'], prediction])
                print(f"Processed index {row['index']}: {prediction}")  # Print progress and prediction
                
                # Store the current image path for deletion in the next iteration
                previous_image_path = f"temp_image_{row['index']}.jpg"
            except Exception as e:
                print(f"Error processing row {row['index']}: {e}")
        
        # Delete the last image
        if previous_image_path and os.path.exists(previous_image_path):
            os.remove(previous_image_path)
    
    print(f"Predictions completed and saved to {output_filename}")